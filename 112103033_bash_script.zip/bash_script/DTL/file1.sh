#!/bin/bash -xv

echo ${8} ${1} ${18} ${19} ${8}
