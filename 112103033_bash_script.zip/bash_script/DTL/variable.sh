#!/bin/bash
name="Harshwardhan Deshmukh"
echo my name is ${name}.
