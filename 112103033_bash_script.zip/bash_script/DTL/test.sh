#! /bin/bash
title="Hello"
echo ${title}
