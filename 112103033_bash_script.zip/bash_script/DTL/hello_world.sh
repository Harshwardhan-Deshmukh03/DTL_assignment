#!/bin/bash 
#This is DTL Assignment of bash scripting
echo "Hello World, I am Harshwardhan Deshmukh!"

