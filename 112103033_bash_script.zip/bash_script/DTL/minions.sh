#! /bin/bash
friend1="Parth Mane"
friend2="Jia Johnson"
friend3="Bhakti Jaybhay"
friend4="Vardhan Mundada"

echo ${friend1}, ${friend2} , ${friend3}, ${friend4} are my homies.

