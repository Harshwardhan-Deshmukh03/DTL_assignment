echo Heyy I am Harshwardhan
echo I study at COEP
echo I am learning bash
